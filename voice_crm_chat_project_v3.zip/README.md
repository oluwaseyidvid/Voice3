Voice CRM Chat - Project v3 (build-ready, UI-only)
Package: com.neuralic.voicecrm
