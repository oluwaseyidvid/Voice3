package com.neuralic.voicecrm.network

import android.util.Log

object ApiPlaceholders {
    suspend fun analyzeTextWithOpenAI(text: String): String {
        return "Draft: $text"
    }
    suspend fun createPipedriveActivity(summary: String) {
        Log.d("ApiPlaceholders", "createPipedriveActivity -> $summary")
    }
    suspend fun searchWeb(query: String): String {
        return "Search results for: $query"
    }
}
